package com.example.user.dooropenservice.app.Server.ServerCallbackInterface;

public interface ISignUpCallback extends IServerCallback {
    void accessID();

}
