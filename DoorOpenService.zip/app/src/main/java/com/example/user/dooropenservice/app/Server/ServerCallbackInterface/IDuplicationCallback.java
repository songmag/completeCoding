package com.example.user.dooropenservice.app.Server.ServerCallbackInterface;

public interface IDuplicationCallback extends IServerCallback {
    void Duplicate_ID();
    void access();
}
