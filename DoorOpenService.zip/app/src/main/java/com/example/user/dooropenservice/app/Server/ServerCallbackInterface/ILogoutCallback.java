package com.example.user.dooropenservice.app.Server.ServerCallbackInterface;

public interface ILogoutCallback extends IServerCallback {
    void ServerError();
}
